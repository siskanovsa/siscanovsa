package com.example.ratudrink;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class MenuUtama extends AppCompatActivity {

    private onboardingadapter onboardingadapter;
    private LinearLayout layoutOnboardingindicators;
    private MaterialButton buttonOnboardingAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);

        layoutOnboardingindicators = findViewById(R.id.layoutBoardingIndicators);
        buttonOnboardingAction = findViewById(R.id.buttonDashboardingAction);

        setupOnboardingItems();

        final ViewPager2 onboardingViewPager = findViewById(R.id.onboardingViewPager);
        onboardingViewPager.setAdapter(onboardingadapter);

        setupOnboardingIndicators();
        setCurrentOnboardingIndicator(0);

        onboardingViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                setCurrentOnboardingIndicator(position);
            }
        });

        buttonOnboardingAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onboardingViewPager.getCurrentItem() + 1 < onboardingadapter.getItemCount()){
                    onboardingViewPager.setCurrentItem(onboardingViewPager.getCurrentItem() + 1);
                } else {
                    startActivity(new Intent(getApplicationContext(), menulogin.class));
                    finish();

                }
            }
        });
    }

    private void setupOnboardingItems(){
        List<onboardingitem> onboardingitems = new ArrayList<>();

        onboardingitem itemFoodMenu = new onboardingitem();
        itemFoodMenu.setTitle("Order Food You Like");
        itemFoodMenu.setDescription("Kamu bisa pilih menu yang kamu mau lewat aplikasi");
        itemFoodMenu.setImage(R.drawable.img1);

        onboardingitem itemOnTheWay = new onboardingitem();
        itemOnTheWay.setTitle("Delivery to Your Home");
        itemOnTheWay.setDescription("Makanan & minuman kamu kini bisa diantar ke rumah tanpa perlu datang ke tempat.");
        itemOnTheWay.setImage(R.drawable.img2);

        onboardingitem itemPromoFood = new onboardingitem();
        itemPromoFood.setTitle("Get a Variety of Attractive Promos");
        itemPromoFood.setDescription("Berbagai macam promo menarik dan ter-Up to Date bisa kamu dapatkan disini.");
        itemPromoFood.setImage(R.drawable.img3);

        onboardingitems.add(itemFoodMenu);
        onboardingitems.add(itemOnTheWay);
        onboardingitems.add(itemPromoFood);

        onboardingadapter = new onboardingadapter(onboardingitems);


    }

    private void setupOnboardingIndicators(){
        ImageView[] indicators = new ImageView[onboardingadapter.getItemCount()];
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8,0,8,0);
        for (int i = 0 ; i < indicators.length; i++) {
            indicators [i] = new ImageView(getApplicationContext());
            indicators [i].setImageDrawable(ContextCompat.getDrawable(
                    getApplicationContext(),
                    R.drawable.onboardingindicatorinactiv
            ));
            indicators [i].setLayoutParams(layoutParams);
            layoutOnboardingindicators.addView(indicators[i]);
        }
    }

    @SuppressLint("SetTextI18n")
    private void setCurrentOnboardingIndicator(int index){
        int childCount = layoutOnboardingindicators.getChildCount();
        for (int i = 0; i < childCount ; i++){
            ImageView imageView = (ImageView)layoutOnboardingindicators.getChildAt(i);
            if (i == index){
                imageView.setImageDrawable(
                        ContextCompat.getDrawable(getApplicationContext(),R.drawable.onboardingindicatoraction)
                );
            }else {
                imageView.setImageDrawable(
                        ContextCompat.getDrawable(getApplicationContext(), R.drawable.onboardingindicatorinactiv)
            );

            }
        }
        if (index == onboardingadapter.getItemCount() - 1) {
            buttonOnboardingAction.setText("Start");
        }else {
            buttonOnboardingAction.setText("Next");
        }
    }
}
