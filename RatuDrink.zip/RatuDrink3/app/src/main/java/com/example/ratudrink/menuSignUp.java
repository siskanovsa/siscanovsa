package com.example.ratudrink;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class menuSignUp extends AppCompatActivity {
    private RelativeLayout rlayout;
    private Animation animation;
    EditText mfullname,mhandphone,mmailsignup,mpasswordsignup;
    Button msignupbutton;
    TextView mkliksignin;
    FirebaseAuth fAuth;
    ProgressBar mprogressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_sign_up);
        Toolbar toolbar = findViewById(R.id.atas);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        rlayout = findViewById(R.id.rlayout);
        animation = AnimationUtils.loadAnimation(this,R.anim.uptodowndiagonal);
        rlayout.setAnimation(animation);
        mfullname = findViewById(R.id.fullname);
        mhandphone = findViewById(R.id.handphone);
        mmailsignup = findViewById(R.id.mailsignup);
        mpasswordsignup = findViewById(R.id.passwordsignup);
        msignupbutton = findViewById(R.id.signupbutton);
        mkliksignin = findViewById(R.id.kliksignin);
        fAuth = FirebaseAuth.getInstance();
        mprogressBar = findViewById(R.id.progressBar);

        if (fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),menumenu.class));
            finish();
        }

        msignupbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mailsignup = mmailsignup.getText().toString().trim();
                String passwordsignup = mpasswordsignup.getText().toString().trim();

                if(TextUtils.isEmpty(mailsignup)){
                    mmailsignup.setError("Email is Required.");
                    return;
                }
                if (TextUtils.isEmpty(passwordsignup)){
                    mpasswordsignup.setError("Password is Required.");
                    return;
                }
                if(passwordsignup.length() < 6 ){
                    mpasswordsignup.setError("Password Must be > 6 characters");
                    return;
                }

                mprogressBar.setVisibility(View.VISIBLE);

                //Register the User in Firebase

                fAuth.createUserWithEmailAndPassword(mailsignup,passwordsignup).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(menuSignUp.this, "User Created.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),menumenu.class));

                        }else {

                            Toast.makeText(menuSignUp.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }

                    }
                });
            }
        });

        mkliksignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),menulogin.class));

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
