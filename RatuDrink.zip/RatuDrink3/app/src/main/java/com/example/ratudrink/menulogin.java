package com.example.ratudrink;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import static android.app.ActivityOptions.makeSceneTransitionAnimation;

public class menulogin extends AppCompatActivity  implements View.OnClickListener{
    private TextView kliksignup;
    private TextView tvlogin;
    ProgressBar mprogressBarLogin;
    Button mloginbutton;
    EditText memailsignin, mpasswordsignin;
    FirebaseAuth fAuthlogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menulogin);

        kliksignup = findViewById(R.id.kliksignup);
        tvlogin = findViewById(R.id.tvlogin);
        memailsignin = findViewById(R.id.emailsignin);
        mpasswordsignin = findViewById(R.id.passwordsignin);
        kliksignup.setOnClickListener(this);
        fAuthlogin = FirebaseAuth.getInstance();
        mprogressBarLogin = findViewById(R.id.progressBarLogin);

        mloginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailsigin = memailsignin.getText().toString().trim();
                String passwordsignin = mpasswordsignin.getText().toString().trim();

                if(TextUtils.isEmpty(emailsigin)){
                    memailsignin.setError("Email is Required.");
                    return;
                }
                if (TextUtils.isEmpty(passwordsignin)){
                    mpasswordsignin.setError("Password is Required.");
                    return;
                }
                if(passwordsignin.length() < 6 ){
                    mpasswordsignin.setError("Password Must be > 6 characters");
                    return;
                }

                mprogressBarLogin.setVisibility(View.VISIBLE);

                //Register the User in Firebase

                fAuthlogin.createUserWithEmailAndPassword(emailsigin,passwordsignin).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(menulogin.this, "User Created.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),menumenu.class));

                        }else {

                            Toast.makeText(menulogin.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            mprogressBarLogin.setVisibility(View.GONE);

                        }

                    }
                });
            }
        });


        };



        @Override
    public void onClick(View v){
            if (v == kliksignup) {
                Intent intent = new Intent(menulogin.this, menuSignUp.class);
                Pair[] pairs = new Pair[1];
                pairs[0] = new Pair<View, String>(tvlogin, "tvlogin");
                ActivityOptions activityOptions = makeSceneTransitionAnimation(menulogin.this, pairs);
                startActivity(intent, activityOptions.toBundle());
            }
        }

    }
